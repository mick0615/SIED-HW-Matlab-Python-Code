import numpy as np
E = 1
A = 1
L = 1
PHI = [1, 1, 1, 1, 1, 1]
zeta = [0.05, 0.25, 0.05, 0.05, 0.2, 0.05]
K1F = [12*E*A/L, np.cos(np.deg2rad(45)) * 0.5 * E * A / (L * np.sqrt(2)), 6 * E * A / L]
K2F = [12*E*A/L, np.cos(np.deg2rad(45)) * 0.25 * E * A / (L * np.sqrt(2)), 6 * E * A / L]
KF = K1F + K2F

zeta_num = 0
for i in range(len(PHI)):
    zeta_num += zeta[i] * PHI[i] * PHI[i] * KF[i]
    
phit = np.array([1, 2])
K = np.array([[np.sum(K1F) + np.sum(K2F), -np.sum(K2F)],
             [-np.sum(K2F), np.sum(K2F)]])
zeta_den = phit @ K @ phit
zeta = zeta_num / zeta_den
print(f"zeta = {round((zeta * 100), 2)} %") 
