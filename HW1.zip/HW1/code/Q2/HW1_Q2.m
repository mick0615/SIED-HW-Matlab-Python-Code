clc;clear;close all
E = 1;
A = 1;
L = 1;
PHI = [1, 1, 1, 1, 1, 1]; 
zeta = [0.05, 0.25, 0.05, 0.05, 0.2, 0.05];
K1F = [12 * E * A / L, cosd(45) * 0.5 * E * A / (L * sqrt(2)), 6 * E * A / L];
K2F = [12 * E * A / L, cosd(45) * 0.25 * E * A / (L * sqrt(2)), 6 * E * A / L];
KF = [K1F, K2F];

zeta_num = 0;
for i = 1:length(zeta)
    zeta_num = zeta_num + zeta(i) * PHI(i) * PHI(i) * KF(i);
end

phit = [1, 2];
K = [sum(K1F) + sum(K2F), -sum(K2F); 
    -sum(K2F), sum(K2F)];

zeta_den = phit * K * phit';
zeta = zeta_num / zeta_den;

fprintf('zeta = %.2f %%\n', round(zeta * 100, 2));