clc;clear;close all
EQ1 = readmatrix(fullfile(pwd, 'EL Centro.txt'));
%%
figure;
plot(EQ1(:,1), EQ1(:,2) * 9.81, LineWidth=1.5)
xlabel('Time (sec)', FontSize=12)
ylabel('Acceleration (m/s2)', FontSize=12)
title('1940 El Centro Earthquake', FontSize=18)
grid on;
xlim([EQ1(1,1), EQ1(end,1)])
EQ1(:,2)=EQ1(:,2)*9.81*100;
%ans.Eh ans.Es ans.Ek_re ans.Ei_re ans.E_zeta ans.Ek_abs ans.Ei_abs
%% T = 0.09
T = 0.09;
m=100;
wn=2*pi/T;
zeta=0.05;
c=2*m*wn*zeta;
k=m*wn^2;
g=9.81;
W=m*g;
fy=0.1*W;
uy=fy/k;
ky=0.15*k;
sim hw1_Q1
ans.E_zeta(end) = [];
ans.Eh(end) = [];
ans.Es(end) = [];
ans.Ek_re(end) = [];
ans.Ei_re(end) = [];
ans.Ek_abs(end) = [];
ans.Ei_abs(end) = [];

figure;
hold on
plot(EQ1(:,1),ans.Ei_abs, 'm-', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Ek_abs, 'g--', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Es, 'r-', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta+ans.Eh, 'g--', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta, 'b-', LineWidth=1.5);
xlabel('Time (sec)', FontSize=12)
ylabel('Energy (N-cm)', FontSize=12)
title("Ei (absolute), EL Centro NS (T =" + T +  "s)", FontSize=18)
legend('Ei(absolute)', 'E_\xi + E_h', 'E_\xi', 'Location', 'southeast');
xlim([EQ1(1,1), EQ1(end,1)])
ax.YAxis.Exponent = 0;
box on;
grid on;

figure;
hold on
plot(EQ1(:,1),ans.Ei_re, 'm-', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Ek_abs, 'g--', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Es, 'r-', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta+ans.Eh, 'g--', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta, 'b-', LineWidth=1.5);
xlabel('Time (sec)', FontSize=12)
ylabel('Energy (N-cm)', FontSize=12)
title("Ei (relative), EL Centro NS (T =" + T +  "s)", FontSize=18)
legend('Ei(relative)', 'E_\xi + E_h', 'E_\xi', 'Location', 'southeast');
xlim([EQ1(1,1), EQ1(end,1)])
box on;
grid on;
%% T = 1
T = 1;
m=1;
wn=2*pi/T;
zeta=0.05;
c=2*m*wn*zeta;
k=m*wn^2;
g=9.81;
W=m*g;
fy=0.1*W;
uy=fy/k;
ky=0.15*k;
sim hw1_Q1
ans.E_zeta(end) = [];
ans.Eh(end) = [];
ans.Es(end) = [];
ans.Ek_re(end) = [];
ans.Ei_re(end) = [];
ans.Ek_abs(end) = [];
ans.Ei_abs(end) = [];

figure();
hold on
plot(EQ1(:,1),ans.Ei_abs, 'm-', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Ek_abs, 'g--', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Es, 'r-', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta+ans.Eh, 'g--', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta, 'b-', LineWidth=1.5);
xlabel('Time (sec)', FontSize=12)
ylabel('Energy (N-cm)', FontSize=12)
title("Ei (absolute), EL Centro NS (T =" + T +  "s)", FontSize=18)
legend('Ei(absolute)', 'E_\xi + E_h', 'E_\xi', 'Location', 'southeast');
xlim([EQ1(1,1), EQ1(end,1)])
box on;
grid on;

figure;
hold on
plot(EQ1(:,1),ans.Ei_re, 'm-', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Ek_abs, 'g--', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Es, 'r-', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta+ans.Eh, 'g--', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta, 'b-', LineWidth=1.5);
xlabel('Time (sec)', FontSize=12)
ylabel('Energy (N-cm)', FontSize=12)
title("Ei (relative), EL Centro NS (T =" + T +  "s)", FontSize=18)
legend('Ei(relative)', 'E_\xi + E_h', 'E_\xi', 'Location', 'southeast');
xlim([EQ1(1,1), EQ1(end,1)])
box on;
grid on;
%% T = 10
T = 10;
m=1;
wn=2*pi/T;
zeta=0.05;
c=2*m*wn*zeta;
k=m*wn^2;
g=9.81;
W=m*g;
fy=0.1*W;
uy=fy/k;
ky=0.15*k;
sim hw1_Q1
ans.E_zeta(end) = [];
ans.Eh(end) = [];
ans.Es(end) = [];
ans.Ek_re(end) = [];
ans.Ei_re(end) = [];
ans.Ek_abs(end) = [];
ans.Ei_abs(end) = [];

figure;
hold on
plot(EQ1(:,1),ans.Ei_abs, 'm-', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Ek_abs, 'g--', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Es, 'r-', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta+ans.Eh, 'g--', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta, 'b-', LineWidth=1.5);
xlabel('Time (sec)', FontSize=12)
ylabel('Energy (N-cm)', FontSize=12)
title("Ei (absolute), EL Centro NS (T =" + T +  "s)", FontSize=18)
legend('Ei(absolute)', 'E_\xi + E_h', 'E_\xi', 'Location', 'southeast');
xlim([EQ1(1,1), EQ1(end,1)])
box on;
grid on;

figure;
hold on
plot(EQ1(:,1),ans.Ei_re, 'm-', LineWidth=1.5);
%%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Ek_abs, 'g--', LineWidth=1.5);
%plot(EQ1(:,1),ans.E_zeta + ans.Eh + ans.Es, 'r-', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta+ans.Eh, 'g--', LineWidth=1.5);
plot(EQ1(:,1),ans.E_zeta, 'b-', LineWidth=1.5);
xlabel('Time (sec)', FontSize=12)
ylabel('Energy (N-cm)', FontSize=12)
title("Ei (relative), EL Centro NS (T =" + T +  "s)", FontSize=18)
legend('Ei(relative)', 'E_\xi + E_h', 'E_\xi', 'Location', 'southeast');
xlim([EQ1(1,1), EQ1(end,1)])
box on;
grid on;

