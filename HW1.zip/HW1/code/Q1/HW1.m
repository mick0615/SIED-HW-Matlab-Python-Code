%%%%%%%%%%%%%%%%%  Need to wait 5~10 minutes  %%%%%%%%%%%%%%%%%%%%%
clc;clear;close all
EQ1 = readmatrix(fullfile(pwd, 'EL Centro.txt'));
%%
figure;
plot(EQ1(:,1), EQ1(:,2) * 9.81)
xlabel('Time (sec)', FontSize=12)
ylabel('Acceleration (m/s2)', FontSize=12)
title('1940 El Centro Earthquake', FontSize=18)
grid on;
xlim([EQ1(1,1), EQ1(end,1)])
EQ1(:,2)=EQ1(:,2)*9.81*100;
%%
m=1;
T = 0.03:0.1:50;
Wn=2*pi./T;
zeta=0.05;
C=2*m*Wn*zeta;
K=m*Wn.^2;
g=9.81;
W=m*g;
fy=0.1*W;
Uy=fy./K;
Ky=0.15*K;
for i = 1:length(T)
     wn = Wn(i);
     c = C(i);
     k = K(i);
     uy = Uy(i);
     ky = Ky(i);
     sim hw1_Q1 ;
     Vi_abs(i) = sqrt(max(abs(ans.Ei_abs))*2/m);
     Vi_rel(i) = sqrt(max(abs(ans.Ei_re))*2/m);
end
%%
time = EQ1(:, 1);  
acceleration = EQ1(:, 2); 
velocity = cumtrapz(time, acceleration);
max_velocity = max(abs(velocity)) ;
%%
figure;
loglog(T, Vi_abs, T, Vi_rel, 'linewidth', 2);
xlabel('Period (sec)', 'FontSize', 12);
ylabel("Vi or Vi' (cm/sec)",'FontSize', 12); 
title('Input Energy Spectrum in terms of Equivalent Velocity ',FontSize =  15);
xlim([0.03, 50]);

set(gca, 'XTick', [0.03, 0.1, 0.5, 5, 50]);

ax = gca;
ax.XMinorGrid = 'on';
ax.XGrid = 'on';

grid on;

set(gca, 'YScale', 'linear');

set(gca, 'GridAlpha', 0.3);  
set(gca, 'MinorGridAlpha', 0.1);  
set(gca, 'LineWidth', 1.5);  

yline(max_velocity, '--', 'LineWidth', 1.5, 'Color', 'k');

legend({'Vi', "Vi'", '$\dot{\mathrm{v}}_{g(\mathrm{max})}$'}, 'Interpreter', 'latex', 'Location', 'best', 'FontSize', 12);

