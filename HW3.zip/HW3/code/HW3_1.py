import numpy as np
import matplotlib.pyplot as plt
import os
  
kc = 3              # Lateral Stiffness of each column (ton/cm)
omega = np.pi       # Frequency of u(t) and p(t)
amplitude_u = 2     # uo (cm)
amplitude_p = 4     # p0 (ton)
kd_prime = 2 * (amplitude_p / amplitude_u) * np.cos(np.pi/4)         # Storage Stiffness of damper (tonf/cm)
kd_prime_prime = 2 * (amplitude_p / amplitude_u) * np.sin(np.pi/4)   # Loss Stiffness of damper (tonf/cm)
kf = 2 * kc                                                          # Stiffness of Frame (tonf/cm)
ka_prime = kd_prime                                                  # Added component storage stiffness (tonf/cm)
ka_prime_prime = kd_prime_prime                                      # Added component loss stiffness (tonf/cm)
keff = kf + ka_prime                                                 # Storage stiffness of system (tonf/cm)
zeta_eq = ka_prime_prime / (2 *(kf + ka_prime))                      # Equivalent damping ratio
WD = 2 * np.pi * amplitude_p * amplitude_u * np.sin(np.pi/4)         # Natural Frequency with damping (rad/s)
C_eq = ka_prime_prime / omega                                        # Equivalent Damping coefficient (tonf-s/cm)
print(f"Equivalent damping ratio = {round(zeta_eq * 100, 2)} %")
print(f"Storage stiffness of the system = {round(keff, 3)} (tonf/cm)")

t = np.linspace(0, 2, 1000)

# Displacement and velocity
u_t = amplitude_u * np.sin(omega * t)  # cm
u_dot_t = amplitude_u * omega * np.cos(omega * t)  # cm/s

# Force for system P(t)
P_t = C_eq * u_dot_t + keff * u_t

# Force for VE damper P_VE(t)
P_VE_t = C_eq * u_dot_t + ka_prime * u_t

output_folder = os.path.join(os.getcwd(),'HW3-1 plot')
if not os.path.exists(output_folder):
    os.makedirs(output_folder)
    
VE_path = os.path.join(output_folder, 'Hysteresis Loop of VE Damper.png')
System_path = os.path.join(output_folder, 'Hysteresis Loop of System.png')
Combined_path = os.path.join(output_folder, 'Combined_Hysteresis_Loop.png')

plt.figure()
plt.plot(u_t, P_VE_t, label="VE Damper Hysteresis Loop")
plt.xlabel("Displacement (cm)", fontsize = 12)
plt.ylabel("Force (tf)", fontsize = 12)
plt.title("Hysteresis Loop of VE Damper", fontsize = 15)
plt.grid(True)
plt.savefig(VE_path)
plt.close() 

plt.figure()
plt.plot(u_t, P_t, label="System Hysteresis Loop")
plt.xlabel("Displacement (cm)", fontsize = 12)
plt.ylabel("Force (tf)", fontsize = 12)
plt.title("Hysteresis Loop of System", fontsize = 15)
plt.grid(True)
plt.savefig(System_path)
plt.close()


fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))

ax1.plot(u_t, P_VE_t)
ax1.set_xlabel("Displacement (cm)", fontsize = 12)
ax1.set_ylabel("Force (tf)", fontsize = 12)
ax1.set_title("Hysteresis Loop of VE Damper", fontsize = 15)
ax1.grid(True)

ax2.plot(u_t, P_t)
ax2.set_xlabel("Displacement (cm)", fontsize = 12)
ax2.set_ylabel("Force (tf)", fontsize = 12)
ax2.set_title("Hysteresis Loop of System", fontsize = 15)
ax2.grid(True)

plt.tight_layout()
plt.savefig(Combined_path)
plt.show()
