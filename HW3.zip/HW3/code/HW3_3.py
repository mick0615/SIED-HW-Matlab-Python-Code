## Empirical Formula
e_a = 0.0266; b = 0.345; c = -0.185; d = -0.0961
e_g = 4.0245; h = 0.189; i = -0.492; j = 0.00784
f = 0.831  # Hz
r0 = 3     # 300%
T0 = 20    # ℃
G_prime = e_a * f**(b) * r0**(d) * T0**(c)      # kN/cm2
Loss_Factor = e_g * f**(h) * r0**(j) * T0**(i)

## VE Damping Coefficient
nVE = 2
tVE = 5     # cm
AVE = 4000  # cm2
w = 5.221   # rad/s
Cd = (Loss_Factor * G_prime * 1000 * nVE * AVE) / (w * tVE)

## Frequency Shift Method
wr = w         # rad/s
wsr = w + 0.5  # rad/s
zeta_eq = Loss_Factor * (1 - ((wr**2) / (wsr**2))) * 100 / 2  # %
