import numpy as np
import pandas as pd  
import os
from scipy.signal import find_peaks
import matplotlib.pyplot as plt
import re
from openpyxl import load_workbook  

dampers = {'Viscoelastic Damper': ['0.3Hz-10mm.txt', '0.5Hz-3mm.txt', '0.5Hz-5mm.txt', '0.5Hz-10mm.txt'],}

Damper_Type = 'Viscoelastic Damper'   
txt_file = '0.5Hz-10mm.txt'         

file_path = os.path.join(os.getcwd(), Damper_Type, txt_file)
data = np.loadtxt(file_path, delimiter='\t', skiprows=1)

pattern = r'(\d+\.?\d*)Hz-(\d+\.?\d*)mm'
match = re.search(pattern, txt_file)

frequency = float(match.group(1))
amplitude = float(match.group(2)) 

time = data[:, 0]
displacement = data[:, 1]
force = data[:, 2]
velocity = np.gradient(displacement, time)

peaks, _ = find_peaks(displacement, distance=50, prominence=0.1)
troughs, _ = find_peaks(-displacement, distance=50, prominence=0.1)
extrema = np.sort(np.concatenate((peaks, troughs)))
extrema_types = ['peak' if idx in peaks else 'trough' for idx in extrema]

cycle_areas, cycle_max_forces, cycle_min_forces, cycle_max_velocities, cycle_min_velocities = [], [], [], [], []
cycle_max_displacements, cycle_min_displacements, cycle_max_displacement_forces, cycle_min_displacement_forces = [], [], [], []
cycle_keffs, cycle_zeta_effs, cycle_loss_factors = [], [], []
cycle_count = 0

output_folder = os.path.join(os.getcwd(),'HW3-2 plot')
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

txt_folder = os.path.join(output_folder, txt_file.replace(".txt", ""))
if not os.path.exists(txt_folder):
    os.makedirs(txt_folder)

plt.figure()

i = 0  
while i < len(extrema) - 2:
    current_type = extrema_types[i]
    next_type = extrema_types[i + 1]
    following_type = extrema_types[i + 2]

    if (current_type == 'peak' and next_type == 'trough' and following_type == 'peak') or \
       (current_type == 'trough' and next_type == 'peak' and following_type == 'trough'):
        start_idx = extrema[i]
        end_idx = extrema[i + 2]
        cycle_indices = np.arange(start_idx, end_idx + 1)
        cycle_displacement = displacement[cycle_indices]
        cycle_force = force[cycle_indices]
        cycle_velocity = velocity[cycle_indices] 

        area = np.abs(np.trapezoid(cycle_force, cycle_displacement))
        cycle_areas.append(area)
        cycle_count += 1

        max_force = np.max(cycle_force)
        min_force = np.min(cycle_force)
        cycle_max_forces.append(max_force)
        cycle_min_forces.append(min_force)

        max_velocity = np.max(cycle_velocity)
        min_velocity = np.min(cycle_velocity)
        cycle_max_velocities.append(max_velocity)
        cycle_min_velocities.append(min_velocity)
        
        max_displacement = np.max(cycle_displacement)
        min_displacement = np.min(cycle_displacement)
        max_displacement_force = cycle_force[np.argmax(cycle_displacement)]
        min_displacement_force = cycle_force[np.argmin(cycle_displacement)]
        
        cycle_max_displacements.append(max_displacement)
        cycle_min_displacements.append(min_displacement)
        cycle_max_displacement_forces.append(max_displacement_force)
        cycle_min_displacement_forces.append(min_displacement_force)
        
        keff = (max_displacement_force - min_displacement_force) / (max_displacement - min_displacement)
        cycle_keffs.append(keff)
        
        zeta_eff = (area * 100) / (2 * np.pi * ((max_displacement - min_displacement) / 2) ** 2 * keff)
        cycle_zeta_effs.append(zeta_eff)
        
        loss_factor = zeta_eff * 2 / 100  
        cycle_loss_factors.append(loss_factor)
        
        plt.plot(cycle_displacement, cycle_force, label=f'Cycle {cycle_count}')


        i += 2
    else:
        i += 1
        
plt.xlabel('Displacement (mm)', fontsize=12)
plt.ylabel('Force (kN)', fontsize=12)
plt.title(f'Hysteresis Loops for each cycles ({txt_file.replace(".txt", "")})', fontsize=15)
plt.legend(title="Cycles")
plt.grid(True)

overlay_image_path = os.path.join(txt_folder, 'Overlay_Hysteresis_Loops.png')
plt.savefig(overlay_image_path)
        
for i, (area, keff, loss) in enumerate(zip(cycle_areas, cycle_keffs, cycle_loss_factors), 1):
    print(f"Cycle {i}:")
    print(f"  Hysteresis Loop Area = {area:.3f} kN·mm")
    print(f"  Storage Stiffness = {keff:.3f} kN/mm")
    print(f"  Loss Factor = {loss:.3f} ")
    

print(f'\nResult of {Damper_Type} {txt_file.replace(".txt","")}')

average_area = np.mean(cycle_areas)
average_keff = np.mean(cycle_keffs)
average_loss_factor = np.mean(cycle_loss_factors)
cycle_area_diffs = [(area - average_area) / average_area * 100 for area in cycle_areas]
cycle_keff_diffs = [(keff - average_keff) / average_keff * 100 for keff in cycle_keffs]
cycle_loss_factor_diffs = [(loss - average_loss_factor) / average_loss_factor * 100 for loss in cycle_loss_factors]


cycle_data = {
    'Cycle Number': list(range(1, cycle_count + 1)),
    'Hysteresis Loop Area (kN·mm)': cycle_areas,
    'Area Difference (%)': cycle_area_diffs,
    'D_max (mm)': cycle_max_displacements,
    'D_min (mm)': cycle_min_displacements,
    'F_max (kN)': cycle_max_forces,
    'F_min (kN)': cycle_min_forces,
    'V_max (mm/s)': cycle_max_velocities,
    'V_min (mm/s)': cycle_min_velocities,
    'Dmax_F (kN)': cycle_max_displacement_forces,
    'D_min_F (kN)': cycle_min_displacement_forces,
    'K_eff (kN/mm)': cycle_keffs,
    'K_eff Difference (%)': cycle_keff_diffs,         
    'ξ_eff (%)': cycle_zeta_effs,
    'Loss Factor η': cycle_loss_factors,
    'Loss Factor Difference (%)': cycle_loss_factor_diffs,
}

df_cycles = pd.DataFrame(cycle_data).round(4)


output_file = Damper_Type + '.xlsx'

if os.path.exists(output_file):
    with pd.ExcelWriter(output_file, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
        sheet_name = txt_file.replace(".txt","")
        df_cycles.to_excel(writer, sheet_name=sheet_name, index=False)
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]
        worksheet.cell(row=len(df_cycles) + 2, column=1, value="Average Area")
        worksheet.cell(row=len(df_cycles) + 2, column=2, value=average_area.round(4))
        worksheet.cell(row=len(df_cycles) + 2, column=12, value=average_keff.round(4))
        worksheet.cell(row=len(df_cycles) + 2, column=15, value=average_loss_factor.round(4))
else:
    with pd.ExcelWriter(output_file, engine='openpyxl', mode='w') as writer:
        sheet_name = txt_file.replace(".txt","")
        df_cycles.to_excel(writer, sheet_name=sheet_name, index=False)
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]
        worksheet.cell(row=len(df_cycles) + 2, column=1, value="Average")
        worksheet.cell(row=len(df_cycles) + 2, column=2, value=average_area.round(4))
        worksheet.cell(row=len(df_cycles) + 2, column=12, value=average_keff.round(4))
        worksheet.cell(row=len(df_cycles) + 2, column=15, value=average_loss_factor.round(4))

plt.figure()
plt.plot(time, displacement)
plt.xlabel('Time (sec)', fontsize=12)
plt.ylabel('Displacement (mm)', fontsize=12)
plt.title(txt_file.replace('.txt', ' Displacement Time History'), fontsize=15)
plt.xlim([time[0], time[-1]])
plt.grid(True)

displacement_image_path = os.path.join(txt_folder, 'Displacement_Time_History.png')
plt.savefig(displacement_image_path)

plt.figure()
plt.plot(displacement, force)
plt.xlabel('Displacement (mm)', fontsize=12)
plt.ylabel('Force (kN)', fontsize=12)
plt.title(txt_file.replace('.txt', ' Hysteresis Loop'), fontsize=15)
plt.grid(True)

hysteresis_image_path = os.path.join(txt_folder, 'Hysteresis_Loop.png')
plt.savefig(hysteresis_image_path)  
plt.show()

print(f'Results have been written to {Damper_Type} in the sheet named {sheet_name}.')
